import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CropAdvisoryWizard from './components/CropAdvisoryWizard';
import StoreCatalog from './components/StoreCatalog';
import ProductModal from './components/ProductModal';
import CartDrawer from './components/CartDrawer';
import RegionalInsights from './components/RegionalInsights';
import WeatherAdvisory from './components/WeatherAdvisory';
import SoilCalculator from './components/SoilCalculator';
import KisanHelp from './components/KisanHelp';
import Footer from './components/Footer';
import { PRODUCTS_DATA } from './data/productsData';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('advisory');
  const [selectedRegion, setSelectedRegion] = useState('north');
  const [searchQuery, setSearchQuery] = useState('');
  const [lang, setLang] = useState('en'); // 'en' or 'hi'

  // Cart state persisted to localStorage
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem('agriconnect_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [modalProduct, setModalProduct] = useState(null);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    try {
      localStorage.setItem('agriconnect_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error(e);
    }
  }, [cartItems]);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3000);
  };

  // Cart operations
  const handleAddToCart = (product, quantity) => {
    if (quantity <= 0) {
      handleRemoveItem(product.id);
      return;
    }

    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.id === product.id ? { ...i, quantity: quantity } : i
        );
      } else {
        return [...prev, { ...product, quantity }];
      }
    });

    showToast(`Added ${product.name} to cart`);
  };

  const handleUpdateQty = (productId, quantity) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((i) => (i.id === productId ? { ...i, quantity } : i))
    );
  };

  const handleRemoveItem = (productId) => {
    setCartItems((prev) => prev.filter((i) => i.id !== productId));
    showToast('Item removed from cart');
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Navigating to store with pre-filtered query from Crop Advisory
  const handleSelectProductForStore = (productKeyword) => {
    setSearchQuery(productKeyword);
    setActiveTab('store');
    window.scrollTo({ top: 450, behavior: 'smooth' });
  };

  const cartTotalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans selection:bg-agri-200 selection:text-agri-950">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 border border-slate-700 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartTotalCount}
        setIsCartOpen={setIsCartOpen}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        lang={lang}
        setLang={setLang}
        selectedRegion={selectedRegion}
        setSelectedRegion={setSelectedRegion}
      />

      {/* Hero Banner */}
      <Hero
        onExploreCrops={() => {
          setActiveTab('advisory');
          const el = document.getElementById('crop-advisory-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onShopStore={() => {
          setActiveTab('store');
          const el = document.getElementById('agri-store-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        selectedRegion={selectedRegion}
        setSelectedRegion={setSelectedRegion}
        lang={lang}
      />

      {/* Main Tabbed Views */}
      <main className="flex-1">
        {activeTab === 'advisory' && (
          <CropAdvisoryWizard
            selectedRegion={selectedRegion}
            setSelectedRegion={setSelectedRegion}
            onSelectProductForStore={handleSelectProductForStore}
            lang={lang}
          />
        )}

        {activeTab === 'store' && (
          <StoreCatalog
            onAddToCart={handleAddToCart}
            onOpenProductModal={(prod) => setModalProduct(prod)}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedRegion={selectedRegion}
            setSelectedRegion={setSelectedRegion}
            cartItems={cartItems}
            lang={lang}
          />
        )}

        {activeTab === 'regions' && (
          <RegionalInsights
            onSelectRegion={(reg) => {
              setSelectedRegion(reg);
              setActiveTab('advisory');
              window.scrollTo({ top: 400, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {activeTab === 'weather' && (
          <WeatherAdvisory
            selectedRegion={selectedRegion}
            setSelectedRegion={setSelectedRegion}
            lang={lang}
          />
        )}

        {activeTab === 'calculator' && (
          <SoilCalculator
            onAddToCart={handleAddToCart}
            lang={lang}
          />
        )}

        {activeTab === 'schemes' && (
          <KisanHelp lang={lang} />
        )}

        {/* If viewing other tabs, also display quick sections below for rich exploratory UX */}
        {activeTab === 'advisory' && (
          <>
            <StoreCatalog
              onAddToCart={handleAddToCart}
              onOpenProductModal={(prod) => setModalProduct(prod)}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedRegion={selectedRegion}
              setSelectedRegion={setSelectedRegion}
              cartItems={cartItems}
              lang={lang}
            />
            <RegionalInsights
              onSelectRegion={(reg) => {
                setSelectedRegion(reg);
                window.scrollTo({ top: 400, behavior: 'smooth' });
              }}
              lang={lang}
            />
            <WeatherAdvisory
              selectedRegion={selectedRegion}
              setSelectedRegion={setSelectedRegion}
              lang={lang}
            />
            <SoilCalculator
              onAddToCart={handleAddToCart}
              lang={lang}
            />
            <KisanHelp lang={lang} />
          </>
        )}
      </main>

      {/* Product Detail Modal */}
      {modalProduct && (
        <ProductModal
          product={modalProduct}
          onClose={() => setModalProduct(null)}
          onAddToCart={handleAddToCart}
          lang={lang}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        lang={lang}
      />

      {/* Footer */}
      <Footer
        onSelectTab={setActiveTab}
        onSelectRegion={setSelectedRegion}
        lang={lang}
      />
    </div>
  );
}
